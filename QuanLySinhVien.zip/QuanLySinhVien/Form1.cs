﻿using QuanLySinhVien;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLySinhVien
{
    public partial class Form1 : Form
    {
        private List<SinhVien> danhSachToanCuc = new List<SinhVien>();
        private bool isAdding = false; // (Nếu bạn đã cài chức năng Thêm/Sửa)
        public Form1()
        {

            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void btnNapDanhSach_Click(object sender, EventArgs e)
        {

            {

                List<SinhVien> lst = new List<SinhVien>();
                string filename = "D:\\2025-2026\\XD_ung_dung_NET_Framework\\Baitap\\C4\\QuanLySinhVien\\SV.txt";

                if (!File.Exists(filename))
                {
                    MessageBox.Show("Không tìm thấy file SV.txt!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Đọc từng dòng trong file SV.txt
                using (StreamReader sr = new StreamReader(filename))
                {
                    while (!sr.EndOfStream)
                    {
                        string line = sr.ReadLine();
                        if (string.IsNullOrWhiteSpace(line)) continue;

                        // Mẫu dòng: SV001,Nguyễn Văn An,T101,Nam,15/5/2004,Sinh viên năm 2
                        string[] info = line.Split(',');
                        if (info.Length < 6) continue;

                        string ma = info[0].Trim();
                        string ten = info[1].Trim();
                        string maNganh = info[2].Trim();
                        bool gioiTinhNam = info[3].Trim().Equals("Nam", StringComparison.OrdinalIgnoreCase);

                        DateTime ngaySinh;
                        DateTime.TryParseExact(info[4].Trim(), "d/M/yyyy", null,
                            System.Globalization.DateTimeStyles.None, out ngaySinh);

                        string ghiChu = info[5].Trim();

                        SinhVien sv = new SinhVien
                        {
                            MaSinhVien = ma,
                            HoTen = ten,
                            MaNganhDaoTao = maNganh,
                            GioiTinhNam = gioiTinhNam,
                            NgaySinh = ngaySinh,
                            GhiChu = ghiChu
                        };

                        lst.Add(sv);
                    }
                }

                //  Hiển thị danh sách lên ListBox
                lbxSinhVien.Items.Clear();
                for (int i = 0; i < lst.Count; i++)
                {
                    lbxSinhVien.Items.Add(lst[i]); // cần ToString() trong class SinhVien
                }
                //hiển thị phần tử đang chọn hiện tại
                //<-->  Kích hoạt sự kiện
                lbxSinhVien_SelectedIndexChanged(null, null);

                // Hiển thị thông tin thống kê
                lblThongke.Text = string.Format("Danh sách có {0} sinh viên", lst.Count);
            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            btnNapDanhSach_Click(null, null);
        }

        private void lbxSinhVien_EnabledChanged(object sender, EventArgs e)
        {

        }

        private void lbxSinhVien_SelectedIndexChanged(object sender, EventArgs e)
        {


            if (lbxSinhVien.SelectedItem == null)
            {
                // Reset các trường khi không có mục nào được chọn
                txtMsv.Text = "";
                txtHoTen.Text = "";
                chkGioiTinhNam.Checked = false;
                txtMaNganhDaoTao.Text = "";
                txtNgaySinh.Text = "";
                txtGhiChu.Text = "";
                return;
            }

            // Lấy đối tượng SinhVien đang được chọn
            SinhVien x = lbxSinhVien.SelectedItem as SinhVien;

            if (x != null)
            {
                // Trình bày thông tin chi tiết lên GUI
                txtMsv.Text = x.MaSinhVien;
                txtHoTen.Text = x.HoTen;
                chkGioiTinhNam.Checked = x.GioiTinhNam;
                txtMaNganhDaoTao.Text = x.MaNganhDaoTao;
                // Định dạng ngày sinh khi hiển thị
                txtNgaySinh.Text = x.NgaySinh.ToString("dd/MM/yyyy");
                txtGhiChu.Text = x.GhiChu;
            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            SinhVien svCanXoa = lbxSinhVien.SelectedItem as SinhVien;

            if (svCanXoa == null)
            {
                MessageBox.Show("Vui lòng chọn một sinh viên để xóa.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DialogResult confirm = MessageBox.Show(
                $"Bạn có chắc chắn muốn xóa sinh viên {svCanXoa.HoTen} không?",
                "Xác nhận Xóa",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (confirm == DialogResult.Yes)
            {
                // Xóa khỏi danh sách toàn cục
                lbxSinhVien.Items.Remove(svCanXoa);

                //  GHI LẠI FILE SAU KHI XÓA 
                List<SinhVien> danhSachtoancuc = new List<SinhVien>();
                foreach (SinhVien sv in lbxSinhVien.Items)
                    danhSachtoancuc.Add(sv);
                string filename = "D:\\2025-2026\\XD_ung_dung_NET_Framework\\Baitap\\C4\\QuanLySinhVien\\SV.txt";
                File.WriteAllLines(filename, danhSachtoancuc.Select(sv =>
                    $"{sv.MaSinhVien},{sv.HoTen},{sv.MaNganhDaoTao},{(sv.GioiTinhNam ? "Nam" : "Nữ")},{sv.NgaySinh:dd/MM/yyyy},{sv.GhiChu}"
                ));

                // CẬP NHẬT GIAO DIỆN
                lbxSinhVien.DataSource = null;
                lbxSinhVien.DataSource = danhSachtoancuc;
                lbxSinhVien.DisplayMember = "HoTen";

                lblThongke.Text = $"Danh sách có {lbxSinhVien.Items.Count} sinh viên";

                // Xóa nội dung trong các TextBox
                txtMsv.Clear();
                txtHoTen.Clear();
                txtMaNganhDaoTao.Clear();
                txtNgaySinh.Clear();
                txtGhiChu.Clear();
                chkGioiTinhNam.Checked = false;

                MessageBox.Show($"Đã xóa sinh viên {svCanXoa.HoTen} thành công.", "Hoàn tất", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {

        }
    }
}
    


