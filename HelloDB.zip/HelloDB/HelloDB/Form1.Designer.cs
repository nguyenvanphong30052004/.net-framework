﻿using System;
using System.Windows.Forms;

namespace HelloDB
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.button1 = new System.Windows.Forms.Button();
            this.grgrgg = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.btnNhieuHangNhieuCot = new System.Windows.Forms.Button();
            this.KetQuaGrid = new System.Windows.Forms.DataGridView();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.btnNganhDaoTao = new System.Windows.Forms.Button();
            this.GridKetQua1 = new System.Windows.Forms.DataGridView();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.btnSelectNhieuHangNhieuCot = new System.Windows.Forms.Button();
            this.GridKetQua = new System.Windows.Forms.DataGridView();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.chkGioiTinhNam = new System.Windows.Forms.CheckBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button12 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.txtGhiChu = new System.Windows.Forms.Button();
            this.txtNganhDaoTao = new System.Windows.Forms.Button();
            this.dtpNgaySinh = new System.Windows.Forms.Button();
            this.txtHoTen = new System.Windows.Forms.Button();
            this.txtMaSinhVien = new System.Windows.Forms.Button();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.grgrgg.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.KetQuaGrid)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GridKetQua1)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GridKetQua)).BeginInit();
            this.tabPage4.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(12, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 20);
            this.button1.TabIndex = 1;
            this.button1.Text = "Truy vấn";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // grgrgg
            // 
            this.grgrgg.Controls.Add(this.tabPage1);
            this.grgrgg.Controls.Add(this.tabPage2);
            this.grgrgg.Controls.Add(this.tabPage3);
            this.grgrgg.Controls.Add(this.tabPage4);
            this.grgrgg.Location = new System.Drawing.Point(12, 12);
            this.grgrgg.Name = "grgrgg";
            this.grgrgg.SelectedIndex = 0;
            this.grgrgg.Size = new System.Drawing.Size(776, 412);
            this.grgrgg.TabIndex = 2;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.btnNhieuHangNhieuCot);
            this.tabPage1.Controls.Add(this.KetQuaGrid);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(768, 386);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "tabPage1";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // btnNhieuHangNhieuCot
            // 
            this.btnNhieuHangNhieuCot.Location = new System.Drawing.Point(21, 0);
            this.btnNhieuHangNhieuCot.Name = "btnNhieuHangNhieuCot";
            this.btnNhieuHangNhieuCot.Size = new System.Drawing.Size(75, 23);
            this.btnNhieuHangNhieuCot.TabIndex = 1;
            this.btnNhieuHangNhieuCot.Text = "Truy vấn";
            this.btnNhieuHangNhieuCot.UseVisualStyleBackColor = true;
            this.btnNhieuHangNhieuCot.Click += new System.EventHandler(this.btnSelectNhieuHangNhieuCot_Click);
            // 
            // KetQuaGrid
            // 
            this.KetQuaGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.KetQuaGrid.Location = new System.Drawing.Point(6, 24);
            this.KetQuaGrid.Name = "KetQuaGrid";
            this.KetQuaGrid.Size = new System.Drawing.Size(756, 356);
            this.KetQuaGrid.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.btnNganhDaoTao);
            this.tabPage2.Controls.Add(this.GridKetQua1);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(768, 386);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "tabPage2";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // btnNganhDaoTao
            // 
            this.btnNganhDaoTao.Location = new System.Drawing.Point(19, 8);
            this.btnNganhDaoTao.Name = "btnNganhDaoTao";
            this.btnNganhDaoTao.Size = new System.Drawing.Size(214, 23);
            this.btnNganhDaoTao.TabIndex = 1;
            this.btnNganhDaoTao.Text = "Truy Vấn Ngành Đào Tạo\r\n";
            this.btnNganhDaoTao.UseVisualStyleBackColor = true;
            this.btnNganhDaoTao.Click += new System.EventHandler(this.btnNganhDaoTao_Click);
            // 
            // GridKetQua1
            // 
            this.GridKetQua1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GridKetQua1.Location = new System.Drawing.Point(-145, 37);
            this.GridKetQua1.Name = "GridKetQua1";
            this.GridKetQua1.Size = new System.Drawing.Size(907, 343);
            this.GridKetQua1.TabIndex = 0;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.btnSelectNhieuHangNhieuCot);
            this.tabPage3.Controls.Add(this.GridKetQua);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(768, 386);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "tabPage3";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // btnSelectNhieuHangNhieuCot
            // 
            this.btnSelectNhieuHangNhieuCot.Location = new System.Drawing.Point(26, 7);
            this.btnSelectNhieuHangNhieuCot.Name = "btnSelectNhieuHangNhieuCot";
            this.btnSelectNhieuHangNhieuCot.Size = new System.Drawing.Size(75, 23);
            this.btnSelectNhieuHangNhieuCot.TabIndex = 1;
            this.btnSelectNhieuHangNhieuCot.Text = "Truy vấn";
            this.btnSelectNhieuHangNhieuCot.UseVisualStyleBackColor = true;
            this.btnSelectNhieuHangNhieuCot.Click += new System.EventHandler(this.btnSelect1GiaTri_Click);
            // 
            // GridKetQua
            // 
            this.GridKetQua.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GridKetQua.Location = new System.Drawing.Point(3, 36);
            this.GridKetQua.Name = "GridKetQua";
            this.GridKetQua.Size = new System.Drawing.Size(759, 344);
            this.GridKetQua.TabIndex = 0;
            this.GridKetQua.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.GridKetQua_CellContentClick);
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.dateTimePicker1);
            this.tabPage4.Controls.Add(this.chkGioiTinhNam);
            this.tabPage4.Controls.Add(this.textBox5);
            this.tabPage4.Controls.Add(this.textBox4);
            this.tabPage4.Controls.Add(this.textBox2);
            this.tabPage4.Controls.Add(this.textBox1);
            this.tabPage4.Controls.Add(this.button12);
            this.tabPage4.Controls.Add(this.button11);
            this.tabPage4.Controls.Add(this.button9);
            this.tabPage4.Controls.Add(this.button8);
            this.tabPage4.Controls.Add(this.button10);
            this.tabPage4.Controls.Add(this.button7);
            this.tabPage4.Controls.Add(this.txtGhiChu);
            this.tabPage4.Controls.Add(this.txtNganhDaoTao);
            this.tabPage4.Controls.Add(this.dtpNgaySinh);
            this.tabPage4.Controls.Add(this.txtHoTen);
            this.tabPage4.Controls.Add(this.txtMaSinhVien);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(768, 386);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "tabPage4";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(155, 187);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(232, 20);
            this.dateTimePicker1.TabIndex = 3;
            // 
            // chkGioiTinhNam
            // 
            this.chkGioiTinhNam.AutoSize = true;
            this.chkGioiTinhNam.Location = new System.Drawing.Point(155, 116);
            this.chkGioiTinhNam.Name = "chkGioiTinhNam";
            this.chkGioiTinhNam.Size = new System.Drawing.Size(89, 17);
            this.chkGioiTinhNam.TabIndex = 2;
            this.chkGioiTinhNam.Text = "Giới tính nam";
            this.chkGioiTinhNam.UseVisualStyleBackColor = true;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(155, 244);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(232, 20);
            this.textBox5.TabIndex = 1;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(155, 139);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(232, 20);
            this.textBox4.TabIndex = 1;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(155, 79);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(232, 20);
            this.textBox2.TabIndex = 1;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(155, 39);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(232, 20);
            this.textBox1.TabIndex = 1;
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(1528, -40);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(120, 23);
            this.button12.TabIndex = 0;
            this.button12.Text = "Ghi chú";
            this.button12.UseVisualStyleBackColor = true;
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(1015, 125);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(120, 23);
            this.button11.TabIndex = 0;
            this.button11.Text = "Ghi chú";
            this.button11.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(1030, -22);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(120, 23);
            this.button9.TabIndex = 0;
            this.button9.Text = "Ghi chú";
            this.button9.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(465, 298);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(120, 23);
            this.button8.TabIndex = 0;
            this.button8.Text = "Delete";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(609, 298);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(120, 23);
            this.button10.TabIndex = 0;
            this.button10.Text = "Update";
            this.button10.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(300, 298);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(120, 23);
            this.button7.TabIndex = 0;
            this.button7.Text = "Insert";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.btnInsert_Click);
            // 
            // txtGhiChu
            // 
            this.txtGhiChu.Location = new System.Drawing.Point(19, 244);
            this.txtGhiChu.Name = "txtGhiChu";
            this.txtGhiChu.Size = new System.Drawing.Size(120, 23);
            this.txtGhiChu.TabIndex = 0;
            this.txtGhiChu.Text = "Ghi chú";
            this.txtGhiChu.UseVisualStyleBackColor = true;
            // 
            // txtNganhDaoTao
            // 
            this.txtNganhDaoTao.Location = new System.Drawing.Point(19, 136);
            this.txtNganhDaoTao.Name = "txtNganhDaoTao";
            this.txtNganhDaoTao.Size = new System.Drawing.Size(120, 23);
            this.txtNganhDaoTao.TabIndex = 0;
            this.txtNganhDaoTao.Text = "Ngành đào tạo";
            this.txtNganhDaoTao.UseVisualStyleBackColor = true;
            // 
            // dtpNgaySinh
            // 
            this.dtpNgaySinh.Location = new System.Drawing.Point(19, 184);
            this.dtpNgaySinh.Name = "dtpNgaySinh";
            this.dtpNgaySinh.Size = new System.Drawing.Size(120, 23);
            this.dtpNgaySinh.TabIndex = 0;
            this.dtpNgaySinh.Text = "Ngày sinh";
            this.dtpNgaySinh.UseVisualStyleBackColor = true;
            // 
            // txtHoTen
            // 
            this.txtHoTen.Location = new System.Drawing.Point(19, 79);
            this.txtHoTen.Name = "txtHoTen";
            this.txtHoTen.Size = new System.Drawing.Size(120, 23);
            this.txtHoTen.TabIndex = 0;
            this.txtHoTen.Text = "Họ tên";
            this.txtHoTen.UseVisualStyleBackColor = true;
            // 
            // txtMaSinhVien
            // 
            this.txtMaSinhVien.Location = new System.Drawing.Point(19, 39);
            this.txtMaSinhVien.Name = "txtMaSinhVien";
            this.txtMaSinhVien.Size = new System.Drawing.Size(120, 23);
            this.txtMaSinhVien.TabIndex = 0;
            this.txtMaSinhVien.Text = "Mã Sinh Viên";
            this.txtMaSinhVien.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.grgrgg);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.grgrgg.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.KetQuaGrid)).EndInit();
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.GridKetQua1)).EndInit();
            this.tabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.GridKetQua)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.ResumeLayout(false);

        }

        private void GridKetQua_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            throw new NotImplementedException();
        }

        #endregion
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TabControl grgrgg;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.DataGridView GridKetQua;
        private System.Windows.Forms.Button btnSelectNhieuHangNhieuCot;
        private Button btnNhieuHangNhieuCot;
        private DataGridView KetQuaGrid;
        private Button btnNganhDaoTao;
        private DataGridView GridKetQua1;
        private TabPage tabPage4;
        private Button txtMaSinhVien;
        private TextBox textBox5;
        private TextBox textBox4;
        private TextBox textBox2;
        private TextBox textBox1;
        private Button txtGhiChu;
        private Button txtNganhDaoTao;
        private Button dtpNgaySinh;
        private Button txtHoTen;
        private ToolTip toolTip1;
        private CheckBox chkGioiTinhNam;
        private Button button12;
        private Button button11;
        private Button button9;
        private Button button8;
        private Button button10;
        private Button button7;
        private DateTimePicker dateTimePicker1;
    }
}

