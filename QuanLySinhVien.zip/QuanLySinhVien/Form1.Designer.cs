﻿namespace QuanLySinhVien
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.txtHoTen = new System.Windows.Forms.TextBox();
            this.lbxSinhVien = new System.Windows.Forms.ListBox();
            this.txtMsv = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtMaNganhDaoTao = new System.Windows.Forms.TextBox();
            this.txtNgaySinh = new System.Windows.Forms.TextBox();
            this.txtGhiChu = new System.Windows.Forms.TextBox();
            this.chkGioiTinhNam = new System.Windows.Forms.CheckBox();
            this.lblThongke = new System.Windows.Forms.Label();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.btxNapDanhSach = new System.Windows.Forms.ToolStripLabel();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtHoTen
            // 
            this.txtHoTen.Location = new System.Drawing.Point(542, 129);
            this.txtHoTen.Name = "txtHoTen";
            this.txtHoTen.Size = new System.Drawing.Size(327, 26);
            this.txtHoTen.TabIndex = 0;
            this.txtHoTen.Text = "Nguyễn Văn Phong";
            // 
            // lbxSinhVien
            // 
            this.lbxSinhVien.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.lbxSinhVien.FormattingEnabled = true;
            this.lbxSinhVien.IntegralHeight = false;
            this.lbxSinhVien.ItemHeight = 20;
            this.lbxSinhVien.Items.AddRange(new object[] {
            "SV001,Nguyễn Văn An,T101,Nam,15/5/2004,Sinh viên năm 2",
            "SV002,Lê Thị Bình,T101,Nữ,22/10/2003,Đang thực tập",
            "SV003,Trần Đình Cường,T202,Nam,1/1/2004,Đã có chứng chỉ IELTS",
            "SV004,Phạm Thu Duyên,T313,Nữ,30/05/2004,Sinh viên giỏi",
            "SV005,Hoàng Minh Đức,T313,Nam,10/8/2003,Đã hoàn thành đồ án",
            "SV006,Võ Thị Hà,T202,Nữ,5/3/2004,Học bổng loại B",
            "SV007,Phan Thanh Hải,T101,Nam,18/12/2003,Tích cực tham gia câu lạc bộ",
            "SV008,Đỗ Thị Hương,T202,Nữ,2/7/2004,Sinh viên mới",
            "SV009,Bùi Ngọc Khoa,T313,Nam,25/9/2003,Đang học thêm tiếng Nhật",
            "SV010,Nguyễn Thị Lam,T101,Nữ,11/4/2004,Chưa nộp học phí",
            "SV011,Trịnh Văn Mạnh,T202,Nam,20/11/2003,Nghỉ học tạm thời",
            "SV012,Lê Thị Nga,T313,Nữ,8/6/2004,Sinh viên năm cuối",
            "SV013,Phan Anh Phát,T101,Nam,19/1/2004,Đã nhận bằng khen",
            "SV014,Đinh Thị Quỳnh,T202,Nữ,29/3/2003,Chuyển ngành",
            "SV015,Vũ Quang Sơn,T313,Nam,14/7/2003,Đang tìm việc làm",
            "SV016,Nguyễn Thị Thảo,T101,Nữ,3/1/2004,Môn học yếu: Toán",
            "SV017,Lê Văn Trung,T202,Nam,16/9/2004,Sinh viên tiêu biểu",
            "SV018,Hoàng Thị Uyên,T313,Nữ,7/12/2003,Có kinh nghiệm lập trình",
            "SV019,Trần Quốc Việt,T101,Nam,28/2/2004,Tham gia nghiên cứu khoa học",
            "SV020,Phạm Thị Xuân,T202,Nữ,4/10/2003,Đã tốt nghiệp sớm",
            "SV021,Mai Văn Bảo,T313,Nam,17/4/2004,Đang học nâng cao",
            "SV022,Đặng Thu Cúc,T101,Nữ,21/8/2003,Học lại môn Lịch sử",
            "SV023,Nguyễn Đức Dũng,T202,Nam,9/5/2004,Hoàn thành nghĩa vụ quân sự",
            "SV024,Bùi Thị Giang,T313,Nữ,26/11/2003,Đã đóng bảo hiểm y tế",
            "SV025,Lê Văn Hùng,T101,Nam,12/2/2004,Xin cấp lại thẻ sinh viên",
            "SV026,Phan Thị Mai,T202,Nữ,6/7/2003,Tốt nghiệp loại Khá",
            "SV027,Hoàng Minh Nam,T313,Nam,23/10/2004,Đang chuẩn bị thi cuối kỳ",
            "SV028,Đinh Thị Oanh,T101,Nữ,13/3/2003,Sinh viên khóa trước",
            "SV029,Trần Văn Tài,T202,Nam,27/6/2004,Đang làm thêm bán thời gian",
            "SV030,Võ Thị Vân,T313,Nữ,24/1/2003,Sinh viên ưu tú"});
            this.lbxSinhVien.Location = new System.Drawing.Point(44, 80);
            this.lbxSinhVien.Name = "lbxSinhVien";
            this.lbxSinhVien.Size = new System.Drawing.Size(275, 331);
            this.lbxSinhVien.TabIndex = 1;
            this.lbxSinhVien.SelectedIndexChanged += new System.EventHandler(this.lbxSinhVien_SelectedIndexChanged);
            this.lbxSinhVien.EnabledChanged += new System.EventHandler(this.lbxSinhVien_EnabledChanged);
            // 
            // txtMsv
            // 
            this.txtMsv.Location = new System.Drawing.Point(542, 80);
            this.txtMsv.Name = "txtMsv";
            this.txtMsv.Size = new System.Drawing.Size(327, 26);
            this.txtMsv.TabIndex = 2;
            this.txtMsv.Text = "22T1020313\r\n";
            this.txtMsv.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(368, 86);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 20);
            this.label1.TabIndex = 3;
            this.label1.Text = "Mã Sinh Viên:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(368, 204);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(147, 20);
            this.label2.TabIndex = 4;
            this.label2.Text = "Mã Ngành Đào Tạo\r\n";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(368, 132);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 20);
            this.label3.TabIndex = 5;
            this.label3.Text = "Họ Tên:\r\n";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(368, 249);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(81, 20);
            this.label4.TabIndex = 6;
            this.label4.Text = "Ngày Sinh\r\n";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(368, 296);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(67, 20);
            this.label5.TabIndex = 7;
            this.label5.Text = "Ghi Chú";
            // 
            // txtMaNganhDaoTao
            // 
            this.txtMaNganhDaoTao.Location = new System.Drawing.Point(542, 198);
            this.txtMaNganhDaoTao.Name = "txtMaNganhDaoTao";
            this.txtMaNganhDaoTao.Size = new System.Drawing.Size(327, 26);
            this.txtMaNganhDaoTao.TabIndex = 8;
            this.txtMaNganhDaoTao.Text = "T313";
            // 
            // txtNgaySinh
            // 
            this.txtNgaySinh.Location = new System.Drawing.Point(542, 243);
            this.txtNgaySinh.Name = "txtNgaySinh";
            this.txtNgaySinh.Size = new System.Drawing.Size(327, 26);
            this.txtNgaySinh.TabIndex = 9;
            this.txtNgaySinh.Text = "30/05/2004";
            // 
            // txtGhiChu
            // 
            this.txtGhiChu.Location = new System.Drawing.Point(542, 290);
            this.txtGhiChu.Name = "txtGhiChu";
            this.txtGhiChu.Size = new System.Drawing.Size(327, 26);
            this.txtGhiChu.TabIndex = 10;
            this.txtGhiChu.Text = "Thông tin ghi chú ở đây";
            // 
            // chkGioiTinhNam
            // 
            this.chkGioiTinhNam.AutoSize = true;
            this.chkGioiTinhNam.Location = new System.Drawing.Point(542, 161);
            this.chkGioiTinhNam.Name = "chkGioiTinhNam";
            this.chkGioiTinhNam.Size = new System.Drawing.Size(128, 24);
            this.chkGioiTinhNam.TabIndex = 11;
            this.chkGioiTinhNam.Text = "Giới tính nam";
            this.chkGioiTinhNam.UseVisualStyleBackColor = true;
            this.chkGioiTinhNam.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // lblThongke
            // 
            this.lblThongke.AutoSize = true;
            this.lblThongke.Location = new System.Drawing.Point(40, 421);
            this.lblThongke.Name = "lblThongke";
            this.lblThongke.Size = new System.Drawing.Size(194, 20);
            this.lblThongke.TabIndex = 13;
            this.lblThongke.Text = "Danh sách có 30 sinh viên";
            // 
            // toolStrip1
            // 
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton1,
            this.btxNapDanhSach,
            this.toolStripButton2,
            this.toolStripButton3,
            this.toolStripButton4});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(935, 33);
            this.toolStrip1.TabIndex = 14;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(34, 28);
            this.toolStripButton1.Text = "toolStripButton1";
            this.toolStripButton1.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // btxNapDanhSach
            // 
            this.btxNapDanhSach.Name = "btxNapDanhSach";
            this.btxNapDanhSach.Size = new System.Drawing.Size(130, 28);
            this.btxNapDanhSach.Text = "Nạp danh sách";
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(34, 28);
            this.toolStripButton2.Text = "toolStripButton2";
            // 
            // toolStripButton3
            // 
            this.toolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton3.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton3.Image")));
            this.toolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.Size = new System.Drawing.Size(34, 28);
            this.toolStripButton3.Text = "toolStripButton3";
            // 
            // toolStripButton4
            // 
            this.toolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton4.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton4.Image")));
            this.toolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton4.Name = "toolStripButton4";
            this.toolStripButton4.Size = new System.Drawing.Size(34, 28);
            this.toolStripButton4.Text = "toolStripButton4";
            this.toolStripButton4.Click += new System.EventHandler(this.btnXoa_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(935, 453);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.lblThongke);
            this.Controls.Add(this.chkGioiTinhNam);
            this.Controls.Add(this.txtGhiChu);
            this.Controls.Add(this.txtNgaySinh);
            this.Controls.Add(this.txtMaNganhDaoTao);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtMsv);
            this.Controls.Add(this.lbxSinhVien);
            this.Controls.Add(this.txtHoTen);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtHoTen;
        private System.Windows.Forms.ListBox lbxSinhVien;
        private System.Windows.Forms.TextBox txtMsv;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtMaNganhDaoTao;
        private System.Windows.Forms.TextBox txtNgaySinh;
        private System.Windows.Forms.TextBox txtGhiChu;
        private System.Windows.Forms.CheckBox chkGioiTinhNam;
        private System.Windows.Forms.Label lblThongke;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripLabel btxNapDanhSach;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ToolStripButton toolStripButton3;
        private System.Windows.Forms.ToolStripButton toolStripButton4;
    }
}

