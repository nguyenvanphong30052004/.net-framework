﻿using QuanLySinhVien.DAO;
using QuanLySinhVien.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLySinhVien.GUI
{
    public partial class FormSinhVien_Sua : Form
    {
        private SinhVien sv;

        public FormSinhVien_Sua(SinhVien sv)
        {
            InitializeComponent();

            #region Hiển thị dữ liệu của sv lên GUI
            txtMaSinhVien.Text = sv.MaSinhVien;
            txtHoTen.Text = sv.HoTen;

            #region Nạp ds ngành đào tạo từ nguồn dliệu
            NganhDaoTaoDAO daoNDT = new NganhDaoTaoDAO();
            List<NganhDaoTao> lstNDT = daoNDT.DocDanhSach();

            cbxNganhDaoTao.DisplayMember = "ThongTin";
            cbxNganhDaoTao.Items.Clear();
            foreach (NganhDaoTao ndt in lstNDT)
                cbxNganhDaoTao.Items.Add(ndt);
            #endregion

            #region Highlight đúng ngành đào tạo tương ứng sv.MaNganh
            for (int i = 0; i < lstNDT.Count; i++)
                if (lstNDT[i].MaNganhDaoTao == sv.MaNganhDaoTao)
                {
                    cbxNganhDaoTao.SelectedIndex = i;
                    break;
                }
            #endregion

            chkGioiTinhNam.Checked = sv.GioiTinhNam;
            dtpNgaySinh.Value = sv.NgaySinh;
            txtGhiChu.Text = sv.GhiChu;
            #endregion
        }

        private void FormSinhVien_Sua_Load(object sender, EventArgs e)
        {

        }

        private void btnSua(object sender, EventArgs e)
        {
            FormSinhVien_Sua frm = new FormSinhVien_Sua(sv);
            frm.ShowDialog();
        }

        private void btnDongY_Click(object sender, EventArgs e)
        {
            SinhVienDAO daoSV = new SinhVienDAO();
            daoSV.CapNhat(sv);
            this.Close();
        }
    }
}
