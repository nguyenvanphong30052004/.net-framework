﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloDB.Model
{
    public class NganhDaoTao
    {
          
        public string MaNganhDaoTao { get; set; }

        public string TenNganhDaoTao { get; set; }
    }
}

