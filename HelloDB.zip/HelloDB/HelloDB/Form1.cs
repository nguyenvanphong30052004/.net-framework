﻿using HelloDB.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HelloDB
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void btnSelectNhieuHangNhieuCot_Click(object sender, EventArgs e)
        {

            {
                #region 1. Tạo kết nối
                DbConnection cnn = new SqlConnection();
                //cnn.ConnectionString = "Server=localhost;Database=SinhVienDB;User Id=sa;Password=123;";
                cnn.ConnectionString = "Server=localhost;Database=SinhVienDB;Trusted_Connection=True;";

                cnn.Open();
                #endregion

                #region 2. Tạo command
                DbCommand cmd = cnn.CreateCommand();
                cmd.CommandText = @"
  SELECT MaSinhVien, HoTen, GioiTinhNam, NgaySinh, MaNganhDaoTao, GhiChu
    FROM SinhVien
ORDER BY MaNganhDaoTao
";
                #endregion

                #region 3. Thực thi command - trả về nhiều hàng, nhiều cột <-> DbDataReader
                DbDataReader dr = cmd.ExecuteReader();
                #endregion

                #region 4. Khai thác dữ liệu
                List<SinhVien> lst = new List<SinhVien>();
                while (dr.Read())
                {
                    string maSinhVien = dr.GetString(0);
                    string hoTen = dr.GetString(1);
                    bool gioiTinhNam = dr.GetBoolean(2);

                    DateTime? ngaySinh = null;

                    // Cần phải bảo đảm dữ liệu ở cột có chỉ số 3 != NULL thì mới GetValue được
                    if (dr.IsDBNull(3) == false)
                        ngaySinh = dr.GetDateTime(3);

                    string maNganh = dr.GetString(4);
                    string ghiChu = dr.GetString(5);

                    SinhVien sv = new SinhVien()
                    {
                        MaSinhVien = maSinhVien,
                        HoTen = hoTen,
                        GioiTinhNam = gioiTinhNam,
                        NgaySinh = ngaySinh,
                        MaNganhDaoTao = maNganh,
                        GhiChu = ghiChu
                    };
                    lst.Add(sv);
                }
                #endregion

                #region 5. Giải phóng tài nguyên
                dr.Close();
                cnn.Close();
                #endregion


                // Hiển thị danh sách vừa đọc được lên gridKetQua
                KetQuaGrid.AutoGenerateColumns = true;
                KetQuaGrid.DataSource = lst;
            }
        }

        private void btnNganhDaoTao_Click(object sender, EventArgs e)
        {
            {
                #region 1. Tạo kết nối
                DbConnection cnn = new SqlConnection();
                cnn.ConnectionString = "Server=localhost;Database=SinhVienDB;Trusted_Connection=True;";

               
                    // Mở kết nối đến cơ sở dữ liệu
                    cnn.Open();
                    #endregion

                    #region 2. Tạo command
                    DbCommand cmd = cnn.CreateCommand();
                    cmd.CommandText = @"
            SELECT MaNganhDaoTao, TenNganhDaoTao
            FROM NganhDaoTao
            ORDER BY MaNganhDaoTao";
                    #endregion

                    #region 3. Thực thi command - trả về nhiều hàng, nhiều cột <-> DbDataReader
                    DbDataReader dr = cmd.ExecuteReader();
                    #endregion

                    #region 4. Khai thác dữ liệu
                    List<NganhDaoTao> lst = new List<NganhDaoTao>();
                    while (dr.Read())
                    {
                        string maNganh = dr.GetString(0); // Lấy MaNganhDaoTao
                        string tenNganh = dr.IsDBNull(1) ? "" : dr.GetString(1); // Kiểm tra NULL cho TenNganhDaoTao

                        lst.Add(new NganhDaoTao()
                        {
                            MaNganhDaoTao = maNganh,
                            TenNganhDaoTao = tenNganh
                        });
                    }
                    #endregion

                    #region 5. Giải phóng tài nguyên
                    dr.Close();
                    cnn.Close();
                #endregion

                // Hiển thị danh sách ngành đào tạo vào DataGridView
                GridKetQua1.AutoGenerateColumns = true;
                GridKetQua1.DataSource = lst;

             



            }
        }

        private void btnSelect1GiaTri_Click(object sender, EventArgs e)
        {
            // 1. Tạo cnn
            DbConnection cnn = new SqlConnection();
            //cnn.ConnectionString = "Server=localhost;Database=SinhVienDB;User Id=sa;Password=123;";
            cnn.ConnectionString = "Server=localhost;Database=SinhVienDB;Trusted_Connection=True;";

            cnn.Open();
           

            // 2. Tạo cmd
            DbCommand cmd = cnn.CreateCommand();
            cmd.CommandText = @"
SELECT Min(NgaySinh)
FROM SinhVien
WHERE GioiTinhNam = 123
";

            // 3. Thực thi cmd trả về 1 giá trị
            object ketQua = cmd.ExecuteScalar();

            // 4. Khai thác kết quả truy vấn
            DateTime? ngaySinh;
            if (ketQua == null || ketQua == DBNull.Value)
                ngaySinh = null;
            else
                ngaySinh = (DateTime?)ketQua;

            // 5. Giải phóng tài nguyên
            cnn.Close();


            MessageBox.Show("Kết quả truy vấn " + ngaySinh);
        }


        void addParam(DbCommand cmd, String paramName, DbType paramType, object value)
        {
            DbParameter p = cmd.CreateParameter();
            p.ParameterName = paramName;
            p.DbType = paramType;
            p.Value = value;

            cmd.Parameters.Add(p);
        }
        private void btnDelete_Click(object sender, EventArgs e)
        {
            // 1. Tạo cnn
            DbConnection cnn = new SqlConnection();
            //cnn.ConnectionString = "Server=localhost;Database=SinhVienDB;User Id=sa;Password=123;";
            cnn.ConnectionString = "Server=localhost;Database=SinhVienDB;Trusted_Connection=True;";

            cnn.Open();

            // 2. Tạo cmd
            DbCommand cmd = cnn.CreateCommand();
            cmd.CommandText = @"DELETE FROM SinhVien WHERE MaSinhVien = @p1";

            //DbParameter p = cmd.CreateParameter();
            //p.ParameterName = "@p1";
            //p.DbType = DbType.String;
            //p.Value = txtMaSinhVien.Text;

            //cmd.Parameters.Add(p);
            addParam(cmd, "@p1", DbType.String, txtMaSinhVien.Text);

            // 3. Thực thi truy vấn
            int n = cmd.ExecuteNonQuery();

            // 4. Khai thác kết quả truy vấn
            MessageBox.Show("Số dòng bị ảnh hưởng là " + n);

            // 5. Giải phóng tài nguyên
            cnn.Close();
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            // 1. Tạo cnn
            DbConnection cnn = new SqlConnection();
            //cnn.ConnectionString = "Server=localhost;Database=SinhVienDB;User Id=sa;Password=123;";
            cnn.ConnectionString = "Server=localhost;Database=SinhVienDB;Trusted_Connection=True;";

            cnn.Open();

            // 2. Tạo cmd
            DbCommand cmd = cnn.CreateCommand();
            cmd.CommandText = @"
INSERT INTO SinhVien
            (MaSinhVien, HoTen, GioiTinhNam, NgaySinh, MaNganhDaoTao, GhiChu)
VALUES      (@pMaSinhVien, @pHoTen, @pGioiTinhNam,@pNgaySinh,@pMaNganh,@pGhiChu)
";
            addParam(cmd, "@pMaSinhVien", DbType.String, txtMaSinhVien.Text);
            addParam(cmd, "@pHoTen", DbType.String, txtHoTen.Text);
            addParam(cmd, "@pGioiTinhNam", DbType.Boolean, chkGioiTinhNam.Checked);
            addParam(cmd, "@pNgaySinh", DbType.Date, dtpNgaySinh.Value);
            addParam(cmd, "@pMaNganh", DbType.String, txtNganhDaoTao.Text);
            addParam(cmd, "@pGhiChu", DbType.String, txtGhiChu.Text);

            // 3. Thực thi cmd
            int n = cmd.ExecuteNonQuery();

            // 4. Khai thác kq
            if (n == 1)
                MessageBox.Show("Đã insert thành công");
            else
                MessageBox.Show("Lỗi trong quá trình insert");

            // 5. Giải phóng tài nguyên
            cnn.Close();
        }
    }
}


