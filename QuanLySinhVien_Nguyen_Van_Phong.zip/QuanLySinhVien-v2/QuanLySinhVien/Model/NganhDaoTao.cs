﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLySinhVien.Model
{
    public class NganhDaoTao
    {
        public string MaNganhDaoTao { get; set; }
        public string TenNganhDaoTao { get; set; }


        public override string ToString()
        {
            return this.MaNganhDaoTao + " - " + this.TenNganhDaoTao;
        }

    }

}

